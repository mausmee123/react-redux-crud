import logo from './logo.svg';
import './App.css';
import {useState} from "react";
import {useSelector, useDispatch} from "react-redux";
import {incrementCounter, decrementCounter, addUser} from "./redux/actions/action";

function App() {

    // const [counter, setCounter] = useState(0)
    const counter = useSelector(state => state.counter.count);
    const users = useSelector(state => state.user.users);
    const isLoading = useSelector(state => state.user.isLoading);
    const dispatch = useDispatch();

    return (
        <div className="App">
            <button onClick={() => dispatch(incrementCounter())}>
                +
            </button>
            {counter}
            <button onClick={() => dispatch(decrementCounter())}>
                -
            </button>

            <button onClick={() => dispatch(addUser())}>
                Add user
            </button>
        </div>

    );
}


export default App;
