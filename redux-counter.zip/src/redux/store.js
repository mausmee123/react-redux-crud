import {createStore, combineReducers} from "redux";
import counterReducer from "./reducers/reducer"
import userReducer from  "./reducers/userReducer"

const combineReducer = combineReducers({
    counter: counterReducer,
    user:userReducer
});

const store = createStore(
    combineReducer,
    {},
);

export default store;

