import {INCREMENT_COUNT, DECREMENT_COUNT} from "../constans";

const initialState = {
    users: [],
    isLoading: true
};

function userReducer(state = initialState, action) {
    switch (action.type) {
        case "ADD_USER":
            const updatedUser = state.users
            updatedUser.push(action.payload)
            return {
                ...state,
                users: updatedUser
            }
        default:
            return state
    }
}

export default userReducer;