import {INCREMENT_COUNT, DECREMENT_COUNT} from "../constans";

const initialState = {
    count: 0,
};

function counterReducer(state = initialState, action) {
    switch (action.type) {
        case INCREMENT_COUNT:
            console.log("INCREMENT_COUNT", INCREMENT_COUNT)
            return {
                ...state,
                count: state.count + 1
            }
        case DECREMENT_COUNT:
            console.log("DECREMENT_COUNT", DECREMENT_COUNT)
            return {
                ...state,
                count: state.count - 1
            }
        default:
            return state
    }
}

export default counterReducer;