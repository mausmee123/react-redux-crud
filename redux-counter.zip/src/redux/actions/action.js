import {INCREMENT_COUNT, DECREMENT_COUNT} from "../constans";

export const incrementCounter = () => {
    return {
        type: INCREMENT_COUNT,
    }
};

export const decrementCounter = () => {
    return {
        type: DECREMENT_COUNT,
    }
};

export const addUser = (data) => {
    return {
        type: "ADD_USER",
        payload: data
    }
};